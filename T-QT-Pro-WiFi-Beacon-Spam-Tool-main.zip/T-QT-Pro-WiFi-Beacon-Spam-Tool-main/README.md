# T-QT Pro Beacon Spammer V1.0.5

**Professional WiFi Beacon Spam Tool for Security Testing**

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Platform: ESP32](https://img.shields.io/badge/Platform-ESP32--S3-blue.svg)](https://www.espressif.com/en/products/socs/esp32-s3)
[![Status: Production Ready](https://img.shields.io/badge/Status-Production%20Ready-green.svg)]()

---

## 🎯 Overview

The T-QT Pro Beacon Spammer is a professional-grade WiFi security testing tool that generates realistic beacon frames for penetration testing and security research. Built specifically for the LilyGO T-QT Pro ESP32-S3 with circular display.

**✅ Works on both security testing tools AND consumer devices (PC/Phone)**

---

## 🚀 Key Features

- **35+ Beacon Categories** - Government, Corporate, Gaming, International, and more
- **Dual Compatibility** - Visible on security tools AND consumer devices  
- **High Performance** - 500+ beacons per second with proper timing
- **Professional Grade** - Based on Bruce's proven beacon implementation
- **Easy to Use** - Simple button navigation interface
- **Security Research Ready** - Perfect for SD card logging tests

---

## 📋 Quick Start

### Hardware Required
- LilyGO T-QT Pro ESP32-S3 (circular display)
- USB-C programming cable

### Installation
1. Clone this repository
2. Open in PlatformIO or Arduino IDE
3. Build and flash to T-QT Pro
4. Power on and navigate with buttons

### Usage
- **LEFT Button**: Navigate through beacon categories
- **RIGHT Button**: Start/Stop beacon spam
- **Display**: Shows real-time status and beacon count

---

## 🔧 Technical Specs

### Performance
- **Beacon Rate**: 5 SSIDs per 10ms burst
- **Total Output**: 500+ beacons/second
- **Channel Coverage**: 2.4GHz channels 1-11
- **Memory Usage**: 48KB RAM, 58% flash

### WiFi Implementation
- **Mode**: WIFI_MODE_APSTA (dual mode)
- **Interface**: WIFI_IF_STA (critical for compatibility)
- **Packet Size**: 109 bytes (IEEE 802.11 standard)
- **MAC Randomization**: Unique MAC per beacon

---

## 🛡️ Security Testing Use Cases

- **WiFi Penetration Testing** - Overwhelm target scanners
- **Security Tool Validation** - Test detection capabilities
- **Training Scenarios** - Demonstrate beacon flood attacks  
- **Research** - Study WiFi behavior under spam conditions
- **Red Team Exercises** - Realistic attack simulation

---

## 🏗️ Build Instructions

### PlatformIO (Recommended)
```bash
git clone [repository-url]
cd T-QT-Pro-Beacon-Spammer
pio run --target upload
```

### Arduino IDE
1. Install ESP32 board package
2. Install TFT_eSPI library  
3. Configure for T-QT Pro board
4. Open Beacon_Factory.ino
5. Compile and upload

---

## 📂 Project Structure

```
├── Beacon_Factory.ino      # Main Arduino sketch  
├── beacon_core.cpp         # Core beacon implementation
├── platformio.ini          # PlatformIO configuration
├── extras/                 # TFT_eSPI configuration files
└── README.md              # This file
```

---

## 🚨 Legal & Ethical Use

**⚠️ AUTHORIZED TESTING ONLY**

This tool is designed for legitimate security testing and research:
- Only use on networks you own or have explicit permission to test
- Follow all local laws and regulations
- Respect network privacy and security
- Use responsibly for authorized penetration testing

**Disclaimer**: Users are solely responsible for compliance with applicable laws.

---

## 🏆 Technical Credits

- **Based on**: Bruce's proven beacon implementation
- **Hardware**: LilyGO T-QT Pro ESP32-S3
- **Display**: 128x128 GC9A01 circular TFT
- **Framework**: Arduino/ESP-IDF

### Key Technical Breakthroughs
1. **ieee80211_raw_frame_sanity_check()** override - Critical for functionality
2. **Dual compatibility** - Works on security tools AND consumer devices
3. **Optimized timing** - Bruce's exact packet timing for maximum effectiveness
4. **Multi-SSID bursts** - Rapid spam with proper beacon intervals

---

## 📝 Version Information

**Version**: 1.0.5 Final  
**Release Date**: January 2, 2026  
**Status**: Production Ready  
**Tested**: ESP32-S3 T-QT Pro hardware  

---

## 🤝 Contributing

This project is complete and production-ready. For issues or improvements:
1. Test thoroughly on T-QT Pro hardware
2. Follow responsible disclosure for security findings
3. Maintain ethical use guidelines

---

## 📄 License

MIT License - See LICENSE file for details

---

**🎯 Ready for professional WiFi security testing!**