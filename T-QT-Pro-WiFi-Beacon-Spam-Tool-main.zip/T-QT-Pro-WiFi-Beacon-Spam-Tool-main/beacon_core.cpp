/*
 * T-QT Pro Beacon Core Implementation - FIXED VERSION
 * Based on Bruce's working beacon spam implementation
 * 
 * WiFi beacon spamming functionality with circular display UI
 */

#include <Arduino.h>
#include <WiFi.h>
#include "esp_wifi.h"
#include <TFT_eSPI.h>

// Create TFT instance for direct drawing
TFT_eSPI tft = TFT_eSPI();

// Button pins for T-QT Pro
#define PIN_BTN_L  0   // Left button (GPIO 0)
#define PIN_BTN_R  47  // Right button (GPIO 47)

// CRITICAL: Bruce's sanity check override - THIS MAKES IT WORK
extern "C" int __attribute__((weak)) ieee80211_raw_frame_sanity_check(int32_t arg, int32_t arg2, int32_t arg3) {
    if (arg == 31337) return 1;
    else return 0;
}

// Bruce's working beacon template (109 bytes)
constexpr size_t BEACON_PKT_LEN = 109;
const uint8_t beaconPacketTemplate[BEACON_PKT_LEN] = {
    /*  0 - 3  */ 0x80, 0x00, 0x00, 0x00, // Type/Subtype: management beacon frame
    /*  4 - 9  */ 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, // Destination: broadcast
    /* 10 - 15 */ 0x01, 0x02,  0x03, 0x04, 0x05, 0x06, // Source (placeholder - overwritten)
    /* 16 - 21 */ 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, // BSSID (placeholder - overwritten)
    /* 22 - 23 */ 0x00, 0x00, // Fragment & sequence number (SDK will set)
    /* 24 - 31 */ 0x83, 0x51, 0xf7, 0x8f, 0x0f, 0x00, 0x00, 0x00, // Timestamp
    /* 32 - 33 */ 0xe8, 0x03, // Interval (1s)
    /* 34 - 35 */ 0x31, 0x00, // Capability info (will set WPA flag later)
    /* 36 - 37 */ 0x00, 0x20,         // Tag: SSID parameter set, tag length 32 (we will write SSID into bytes 38..69)
    /* 38 - 69 */ 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, // SSID
                  0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, // SSID
                  0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, // SSID
                  0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, // SSID
    /* 70 - 71 */ 0x01, 0x08, // Supported rates tag length 8
    /* 72 */ 0x82,
    /* 73 */ 0x84,
    /* 74 */ 0x8b,
    /* 75 */ 0x96,
    /* 76 */ 0x24,
    /* 77 */ 0x30,
    /* 78 */ 0x48,
    /* 79 */ 0x6c,
    /* 80 - 81 */ 0x03, 0x01,          // Current Channel tag
    /* 82 */ 0x01, // Current channel (overwritten)
    /* 83 - 84 */ 0x30, 0x18, // RSN information (start)
    /* 85 - 86 */ 0x01, 0x00,
    /* 87 - 90 */ 0x00, 0x0f, 0xac, 0x02,
    /* 91 - 92 */ 0x02, 0x00,
    /* 93 -100 */ 0x00, 0x0f, 0xac, 0x04, 0x00, 0x0f, 0xac, 0x04,
    /*101 -102 */ 0x01, 0x00,
    /*103 -106 */ 0x00, 0x0f, 0xac, 0x02,
    /*107 -108 */ 0x00, 0x00
};

// Bruce's beacon preparation function
static inline void prepareBeaconPacket(
    uint8_t outPacket[BEACON_PKT_LEN], const uint8_t macAddr[6], const char *ssid, uint8_t ssidLen,
    uint8_t channel, bool setWPAflag = true
) {
    // copy template into a packet
    memcpy(outPacket, beaconPacketTemplate, BEACON_PKT_LEN);

    // write MAC addresses (source and BSSID)
    memcpy(&outPacket[10], macAddr, 6); // Source
    memcpy(&outPacket[16], macAddr, 6); // BSSID

    // ensure SSID slot is cleared (32 bytes) then copy SSID
    memset(&outPacket[38], 0x20, 32); // keep template behavior
    if (ssidLen > 32) ssidLen = 32;
    if (ssidLen > 0) { memcpy(&outPacket[38], ssid, ssidLen); }

    // set channel and WPA flags
    outPacket[82] = channel;
    outPacket[34] = 0x31;
}

// Bruce's channel management
const uint8_t channels[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}; // used Wi-Fi channels (available: 1-14)
uint8_t channelIndex = 0;
uint8_t wifi_channel = 1;

void nextChannel() {
    const size_t nChannels = sizeof(channels) / sizeof(channels[0]);
    if (nChannels == 0) return;
    channelIndex = (channelIndex + 1) % nChannels;
    uint8_t ch = channels[channelIndex];
    if (ch >= 1 && ch <= 14) {
        wifi_channel = ch;
        esp_wifi_set_channel(wifi_channel, WIFI_SECOND_CHAN_NONE);
    }
}

// Bruce's MAC randomization
void generateRandomWiFiMac(uint8_t *mac) {
    mac[0] = 0x02; // Set locally administered bit
    for (int i = 1; i < 6; i++) { 
        mac[i] = random(0, 255); 
    }
}

// Current channel index for cycling  
uint8_t currentChannel = 0;

// Complete Beacon Categories (from M5StickC Plus2 Spamtastic Beacon)
const char* governmentSSIDs[] = {
    "🕵️ NSA Mobile Monitoring 🕵️", 
    "🎯 CIA Field Office WiFi 🎯",
    "💊 DEA Surveillance Node 💊",
    "🚔 Police_Van_#3 🚔", 
    "📡 Mobile Command Center 📡",
    "⚔️ SWAT Team Alpha ⚔️",
    "🛡️ DHS Mobile Unit 🛡️",
    "💣 ATF Tactical Van 💣",
    "🕴️ Secret Service Mobile 🕴️",
    "🛂 Border Patrol Unit 🛂",
    "💰 IRS Investigation Van 💰",
    "🏛️ Homeland Security Net 🏛️",
    "⭐ Federal Marshal Unit ⭐",
    "🏦 US Treasury Mobile 🏦",
    "🛃 Customs Border WiFi 🛃",
    "🔍 FBI Evidence Unit 🔍",
    "⚖️ DOJ Investigation ⚖️",
    "✈️ TSA Security Check ✈️",
    "🧊 ICE Mobile Command 🧊",
    "🏛️ Federal Court WiFi 🏛️",
    "🏛️ Capitol Police Unit 🏛️",
    "🛡️ Pentagon Secure Net 🛡️"
};

const char* funnySSIDs[] = {
    "🤵 Abraham Linksys 🤵",
    "🛩️ Pretty Fly for a WiFi 🛩️", 
    "👶 Hide Your Kids, Hide Your WiFi 👶",
    "🥋 Wu Tang LAN 🥋",
    "😏 Router? I Barely Know Here! 😏",
    "🦕 The LAN Before Time 🦕",
    "🐑 Silence of the LANs 🐑",
    "🏰 House LANnister 🏰",
    "🎵 This LAN Is My LAN 🎵",
    "🚫 No More Mister WiFi 🚫",
    "👨‍🚀 LAN Solo 👨‍🚀", 
    "🚶‍♂️ Get Off My LAN 🚶‍♂️",
    "🔬 Bill Wi The Science Fi 🔬",
    "🌐 I Am The Internet 🌐",
    "🔥 Drop It Like Its Hotspot 🔥",
    "👑 Martin Router King 👑",
    "❄️ Winternet Is Coming ❄️",
    "💕 Tell My WiFi Love Her 💕",
    "💔 It Hurts When IP 💔",
    "🌮 Nacho WiFi 🌮",
    "👩‍💻 Mom Use This One 👩‍💻"
};

const char* suspiciousSSIDs[] = {
    "🦠 Virus Distribution Center 🦠",
    "🆓 Free WiFi (Totally Safe) 🆓",
    "🍯 Definitely Not A Honeypot 🍯",
    "⚠️ Your Network Is Compromised ⚠️", 
    "🔑 Password Is 123456 🔑",
    "😇 Totally_Not_Malware 😇",
    "👆 Click Here For Viruses 👆",
    "🏴‍☠️ Hacker's Paradise 🏴‍☠️",
    "📊 Data Harvesting Station 📊",
    "💳 Identity Theft Network 💳",
    "🚪 Backdoor Access Point 🚪",
    "🕹️ Malware Command Center 🕹️",
    "🎣 Phishing Network Hub 🎣",
    "💰 Ransomware Distribution 💰",
    "🐴 Trojan Horse WiFi 🐴",
    "👁️ Spyware Collection Point 👁️",
    "🤖 Botnet Control Node 🤖",
    "⌨️ Keylogger Network ⌨️",
    "🔐 Password Stealer WiFi 🔐",
    "💳 Credit Card Skimmer 💳",
    "🆔 Social Security Harvester 🆔",
    "🏦 Bank Account Drainer 🏦"
};

const char* techSSIDs[] = {
    "Loading...",
    "404 Network Not Found",
    "CONNECTING...",
    "Access Denied",
    "Connection Timeout",
    "Network Error 404",
    "SSID Not Found",
    "Please Wait...",
    "Buffering...",
    "System Overload",
    "Fatal Error",
    "Blue Screen WiFi",
    "Kernel Panic",
    "Segmentation Fault",
    "Memory Leak Detected",
    "Stack Overflow",
    "Null Pointer Exception",
    "Runtime Error",
    "Compilation Failed",
    "Syntax Error",
    "Database Connection Lost",
    "Server Not Responding"
};

const char* entertainmentSSIDs[] = {
    "Stark Industries WiFi",
    "Wayne Manor Network",
    "Umbrella Corporation",
    "Cyberdyne Systems",
    "Black Mesa Research",
    "Aperture Science Labs",
    "SHIELD Secure Network",
    "Oscorp Tower WiFi",
    "LexCorp Mobile",
    "Daily Planet WiFi",
    "Stark Tower Network",
    "Avengers Assembly",
    "X-Men School WiFi",
    "Gotham City Network",
    "Metropolis WiFi",
    "S.T.A.R. Labs",
    "Fortress of Solitude",
    "Hall of Justice",
    "Xavier Institute",
    "Baxter Building WiFi",
    "Fantastic Four HQ",
    "Doom Castle Network"
};

const char* offensiveSSIDs[] = {
    "YellAtYourKidsNotMe",
    "Your WiFi Sucks",
    "Stop Using My WiFi",
    "Password Is Go F Yourself",
    "I Hate My Neighbors",
    "Get Your Own Internet",
    "Router Of Holding",
    "WiFi So Hard",
    "Bandwidth Thief Detected",
    "Mom Click Here For WiFi",
    "Stop Stealing My WiFi",
    "Pay For Your Own Internet",
    "Neighbor WiFi Thief",
    "Buy Your Own Router",
    "WiFi Leech Detected",
    "Get A Job Buy WiFi",
    "Stop Being Cheap",
    "WiFi Moocher Alert",
    "Freeloading Neighbor",
    "Password Changed Again",
    "Nice Try Neighbor",
    "Keep Out Cheapskate"
};

const char* gamerSSIDs[] = {
    "🏆 Achievement Unlocked 🏆",
    "🎮 Press Start To Connect 🎮",
    "💀 Game Over Man Game Over 💀",
    "🎯 All Your Base 🎯",
    "🍰 The Cake Is A LIE 🍰",
    "🥇 Xbox Live Gold Required 🥇",
    "🎮 PlayerOne Has Joined 🎮",
    "🔄 Respawn Point Alpha 🔄",
    "👹 Final Boss WiFi 👹",
    "🪙 Insert Coin To Continue 🪙",
    "⚔️ Critical Hit Network ⚔️",
    "🗡️ Legendary Loot WiFi 🗡️",
    "💥 Noob Tube Network 💥",
    "🎯 Headshot WiFi 🎯",
    "💥 Epic Fail Network 💥",
    "🏴‍☠️ Pwned Network 🏴‍☠️",
    "⏰ Lag Spike Central ⏰",
    "⛺ Camping Spot WiFi ⛺",
    "💀 Spawn Kill Network 💀",
    "😡 Rage Quit WiFi 😡",
    "🏆 MLG Pro Network 🏆",
    "🎮 GG Easy WiFi 🎮"
};

const char* foodSSIDs[] = {
    "Pizza Palace WiFi",
    "Taco Bell Supreme",
    "McDonalds WiFi",
    "Starbucks Guest",
    "KFC Secret Recipe",
    "Subway Sandwich WiFi",
    "Burger King Crown",
    "Dominos Delivery",
    "Dennys Open 24/7",
    "Waffle House Emergency",
    "In-N-Out Secret Menu",
    "Chipotle Extra Guac",
    "Five Guys Burgers",
    "Wendy's Fresh Never Frozen",
    "Chick-fil-A My Pleasure",
    "Popeyes Chicken Sandwich",
    "Arby's We Have The Meats",
    "White Castle Sliders",
    "Krispy Kreme Hot Now",
    "Dunkin Donuts WiFi",
    "Tim Hortons Eh",
    "IHOP Pancake Stack"
};

const char* hackingSSIDs[] = {
    "Anonymous Network",
    "Hackerman WiFi", 
    "Elite Hacker Club",
    "Zero Day Exploit",
    "Metasploit Framework",
    "Kali Linux Network",
    "Penetration Testing",
    "Social Engineering",
    "Backdoor Access Point",
    "Root Shell Network",
    "Black Hat Convention",
    "Pwn2Own Network",
    "DEF CON WiFi",
    "2600 Hackers",
    "Buffer Overflow",
    "SQL Injection Point",
    "Cross Site Scripting",
    "Man In The Middle",
    "Packet Sniffing Hub",
    "Wireless Wardriving",
    "WiFi Pineapple",
    "Rubber Ducky Network"
};

// PHASE 2 - Adding 5 more categories (10-14)

const char* corporateSSIDs[] = {
    "Initech WiFi Network",
    "Dunder Mifflin WiFi",
    "Stark Enterprises",
    "Globodyne Corporation", 
    "Acme Corporation",
    "Massive Dynamic",
    "Weyland Industries",
    "Tyrell Corporation",
    "Buy N Large WiFi",
    "Soylent Corp Network",
    "Aperture Science",
    "Black Mesa Corp",
    "OCP Corporation",
    "Mishima Zaibatsu",
    "Shinra Electric",
    "Umbrella Corp WiFi",
    "InGen Corporation",
    "Cyberdyne Systems",
    "Oscorp Industries",
    "LexCorp Enterprises",
    "Queen Industries",
    "Palmer Technologies"
};

const char* adultSSIDs[] = {
    "Girls Gone WiFi",
    "Pretty Fly For A WiFi", 
    "No Clothes Required",
    "Adults Only Network",
    "After Dark WiFi",
    "XXX Entertainment",
    "Red Light District",
    "Mature Content Warning",
    "18+ Verification Required",
    "Parental Controls Off",
    "Adults Only Lounge",
    "Mature Audiences Only",
    "NSFW Network",
    "Adult Swim WiFi",
    "R Rated Network",
    "X Rated Connection",
    "Adults Only Club",
    "Mature Content Zone",
    "18+ Only WiFi",
    "Adults Only Area",
    "Restricted Access",
    "Age Verification Required"
};

const char* alienSSIDs[] = {
    "Area 51 Guest Network",
    "UFO Landing Zone WiFi",
    "Alien Abduction Center",
    "Roswell Incident WiFi",
    "ET Phone Home",
    "Greys Communication Hub",
    "Mars Base Alpha",
    "Galactic Federation Net",
    "Intergalactic WiFi",
    "Beam Me Up Scotty",
    "Close Encounters Net",
    "X-Files Investigation",
    "Flying Saucer WiFi",
    "Crop Circle Network",
    "Alien Autopsy Lab",
    "Space Probe WiFi",
    "Extraterrestrial Net",
    "UFO Sighting Report",
    "Alien Embassy WiFi",
    "Mothership Command"
};

const char* dogSSIDs[] = {
    "Good Boy WiFi",
    "Woof Woof Network",
    "Doggo Internet",
    "Puppers Paradise",
    "Bork Bork WiFi",
    "Golden Retriever Net",
    "Labrador Lab Network",
    "German Shepherd WiFi",
    "Bulldog Broadband",
    "Husky Howl Network",
    "Beagle Bay WiFi",
    "Poodle Paradise Net",
    "Rottweiler Router",
    "Chihuahua Connection",
    "Border Collie Net",
    "Dalmatian Dots WiFi",
    "Boxer Broadcast",
    "Dachshund Data Net",
    "Pitbull Power WiFi",
    "Corgi Castle Network",
    "Shiba Inu Internet",
    "Great Dane Data"
};

const char* catSSIDs[] = {
    "Meow Meow Network",
    "Purr Purr WiFi",
    "Kitty Cat Connection",
    "Feline Fine Network",
    "Cat Nap WiFi",
    "Whiskers WiFi",
    "Tabby Cat Network",
    "Persian Palace WiFi",
    "Siamese Signal",
    "Maine Coon Network",
    "Ragdoll Router",
    "British Shorthair Net",
    "Russian Blue WiFi",
    "Bengal Broadband",
    "Sphynx Sphinx Net",
    "Norwegian Forest WiFi",
    "Scottish Fold Net",
    "Abyssinian Access",
    "Birman Broadband",
    "Himalayan Heights",
    "Manx Manor WiFi",
    "Oriental Shorthair"
};

// PHASE 3 - Adding 5 more categories (15-19)

const char* symbolSSIDs[] = {
    "★☆✦✧WiFi✧✦☆★",
    "♠♣♥♦Network♦♥♣♠",
    "▲▼◄►Net◄►▲▼",
    "●○◐◑WiFi◑◐○●",
    "♪♫♬Music♬♫♪",
    "✓✗✓✗Check✗✓✗✓",
    "←↑→↓Arrow↓→↑←",
    "◊◇◈◉WiFi◉◈◇◊",
    "※※※Warning※※※",
    "☼☽☾Sun&Moon☾☽☼",
    "▓▒░Blocks░▒▓",
    "◄◄Rewind►►",
    "♀♂Gender♂♀",
    "∞∞Infinity∞∞",
    "▲△▼▽Triangles▽▼△▲",
    "◊♦◇♢Diamonds♢◇♦◊",
    "⚡⚡Lightning⚡⚡",
    "✈✈Airplane✈✈",
    "⚠⚠Caution⚠⚠",
    "♨♨Hot Springs♨♨"
};

const char* astrologySSIDs[] = {
    "Aries Rising WiFi",
    "Taurus Bull Network",
    "Gemini Twins Net",
    "Cancer Crab WiFi",
    "Leo Lion Network",
    "Virgo Virgin WiFi",
    "Libra Balance Net",
    "Scorpio Sting WiFi",
    "Sagittarius Archer",
    "Capricorn Goat Net",
    "Aquarius Water WiFi",
    "Pisces Fish Network",
    "Mercury Retrograde",
    "Venus In Love WiFi",
    "Mars Attack Network",
    "Jupiter Expansion",
    "Saturn Return WiFi",
    "Uranus Surprise Net",
    "Neptune Dreams WiFi",
    "Pluto Power Network",
    "Full Moon Energy",
    "New Moon Wishes"
};

const char* astronomySSIDs[] = {
    "Milky Way Galaxy",
    "Solar System WiFi",
    "Black Hole Network",
    "Supernova Explosion",
    "Hubble Telescope Net",
    "International Space",
    "Mars Rover WiFi",
    "Saturn Ring Network",
    "Jupiter Storm WiFi",
    "Venus Hot Spot",
    "Mercury Speed Net",
    "Pluto Dwarf WiFi",
    "Asteroid Belt Net",
    "Comet Tail WiFi",
    "Neutron Star Net",
    "Quasar Signal WiFi",
    "Galaxy Cluster Net",
    "Constellation WiFi",
    "Nebula Cloud Network",
    "Pulsar Beam WiFi",
    "Big Bang Theory",
    "Dark Matter Network"
};

const char* sportsSSIDs[] = {
    "Game Day Network",
    "Super Bowl WiFi",
    "World Cup Network",
    "Olympics 2024 WiFi",
    "NBA Championship",
    "NFL Playoffs WiFi",
    "MLB World Series",
    "NHL Stanley Cup",
    "Tennis Grand Slam",
    "Golf Masters WiFi",
    "Marathon Finish Line",
    "Boxing Ring Network",
    "MMA Octagon WiFi",
    "Formula One Racing",
    "NASCAR Speed WiFi",
    "Soccer Goal Network",
    "Basketball Court",
    "Football Stadium",
    "Baseball Diamond",
    "Hockey Rink WiFi",
    "Track And Field",
    "Swimming Pool Net"
};

const char* varietySSIDs[] = {
    "🎲 Random WiFi Name 🎲",
    "🥯 Everything Bagel Net",
    "🎒 Mixed Bag Network",
    "🌺 Potpourri WiFi 🌺", 
    "📦 Variety Pack Net 📦",
    "🔀 Miscellaneous WiFi",
    "🧩 Odds And Ends Net",
    "🎁 Grab Bag Network 🎁",
    "📦 Surprise WiFi Box",
    "🎰 Lucky Dip Network",
    "❓ Mystery Box WiFi ❓",
    "🗂️ Catch All Network",
    "🍭 Assorted WiFi Mix",
    "⚙️ General Purpose Net",
    "🔧 All Purpose WiFi 🔧",
    "🔄 Multi Use Network",
    "🗡️ Swiss Army WiFi",
    "🃏 Jack Of All Trades",
    "📏 One Size Fits All",
    "🌐 Universal WiFi 🌐",
    "🌍 Global Network Hub",
    "🕸️ Worldwide WiFi Web"
};

// PHASE 4 - Adding 5 more categories (20-24) - THE LEGENDS!

const char* hunterThompsonSSIDs[] = {
    "🦇 Fear And Loathing 🦇",
    "🍺 Buy The Ticket Take Ride",
    "🎪 Circus-Circus WiFi 🎪", 
    "💊 We Had Two Bags Of Grass",
    "🏜️ Bat Country Network 🏜️",
    "🚗 Red Shark WiFi 🚗",
    "🎰 Vegas Baby Vegas 🎰",
    "🦅 American Dream WiFi 🦅",
    "⚡ Weird Vibes Network ⚡",
    "🍸 Mescaline Connection 🍸",
    "🏁 Racing Never Stops 🏁",
    "📰 Rolling Stone WiFi 📰",
    "🔫 Hell's Angels Network 🔫",
    "🌵 Desert Madness WiFi 🌵",
    "🎭 Gonzo Journalism Net 🎭",
    "💀 Death Of American Dream",
    "🏍️ Hells Angels Oakland 🏍️",
    "🍻 Rum Diary Network 🍻",
    "⚰️ Fear Death By Boredom",
    "🎪 Freak Power WiFi 🎪",
    "💥 Too Weird To Live 💥",
    "🌪️ Savage Journey WiFi 🌪️"
};

const char* deadKennedysSSIDs[] = {
    "🏴 Holiday In Cambodia 🏴",
    "💀 Dead Kennedys WiFi 💀",
    "🎸 California Uber Alles 🎸",
    "⚡ Nazi Punks F Off ⚡",
    "🏭 Chemical Warfare Net 🏭",
    "💣 Bleed For Me WiFi 💣",
    "🚫 Police Truck Network 🚫",
    "⭐ Kill The Poor WiFi ⭐",
    "🔥 Fresh Fruit Rotting 🔥",
    "💊 Drug Me Network 💊",
    "🎭 Plastic Surgery Disasters",
    "🌊 Surf City Network 🌊",
    "💀 Frankenchrist WiFi 💀",
    "⚡ Bedtime For Democracy ⚡",
    "🎪 Carnival Of Excess 🎪",
    "💥 Punk Rock Explosion 💥",
    "🏴‍☠️ Anarchy Burger WiFi",
    "🎵 Hardcore Punk Network 🎵",
    "💀 Jello Biafra WiFi 💀",
    "⚡ East Bay Ray Network ⚡",
    "🔊 Maximum Rocknroll 🔊",
    "🎸 Punk Not Dead WiFi 🎸"
};

const char* crassSSIDs[] = {
    "🏴 Crass Punk WiFi 🏴",
    "⚫ Feeding Of 5000 ⚫",
    "💀 Death Is Not The End 💀",
    "⚡ Anarchy Peace WiFi ⚡",
    "🔥 Stations Of Crass 🔥",
    "✊ Fight War Not Wars ✊",
    "🎭 Penis Envy Network 🎭",
    "💣 Bloody Revolutions 💣",
    "🚫 No Authority WiFi 🚫",
    "⚫ Christ The Album ⚫",
    "✊ There Is No Authority ✊",
    "🏴 Anarcho-Punk WiFi 🏴",
    "💀 Do They Owe Us Living 💀",
    "⚡ Reality Asylum WiFi ⚡",
    "🔥 Burning Britain Net 🔥",
    "✊ Fight The Power WiFi ✊",
    "🎪 Circus Of Deceit 🎪",
    "💣 Revolution Now WiFi 💣",
    "🚫 Reject Authority Net 🚫",
    "⚫ Black Flag Rising ⚫",
    "✊ Punk Rock Rebellion ✊",
    "🏴 Anarchy In The UK 🏴"
};

const char* insaneSSIDs[] = {
    "🤪 Totally Insane WiFi 🤪",
    "😵‍💫 Madness Network 😵‍💫",
    "🌀 Dizzy Spiral WiFi 🌀",
    "💥 Mind Blown Network 💥",
    "🎭 Crazy Circus WiFi 🎭",
    "🌪️ Tornado Of Madness 🌪️",
    "🤯 Brain Explosion Net 🤯",
    "🎢 Roller Coaster WiFi 🎢",
    "🌈 Rainbow Madness Net 🌈",
    "⚡ Lightning Crazy WiFi ⚡",
    "🎪 Circus Freakshow 🎪",
    "💀 Skeleton Dance WiFi 💀",
    "🌙 Midnight Madness Net 🌙",
    "🔥 Burning Crazy WiFi 🔥",
    "⭐ Stellar Insanity Net ⭐",
    "💫 Cosmic Chaos WiFi 💫",
    "🌊 Tidal Wave Madness 🌊",
    "🎯 Target Practice Crazy 🎯",
    "🎲 Dice Roll Insanity 🎲",
    "🎊 Party Animal WiFi 🎊",
    "🎈 Balloon Pop Crazy 🎈",
    "🎆 Firework Explosion 🎆"
};

const char* germanSSIDs[] = {
    "🇩🇪 Deutscher WiFi 🇩🇪",
    "🍺 Oktoberfest Network 🍺",
    "🏰 Neuschwanstein WiFi 🏰",
    "🥨 Pretzel Connection 🥨",
    "⚡ Blitzkrieg Network ⚡",
    "🍻 Biergarten WiFi 🍻",
    "🚗 Autobahn Network 🚗",
    "🏭 Deutsche Qualität 🏭",
    "🎼 Beethoven WiFi 🎼",
    "⚽ Fußball Network ⚽",
    "🍖 Bratwurst WiFi 🍖",
    "🏔️ Schwarzwald Network 🏔️",
    "🎪 Karneval WiFi 🎪",
    "💎 BMW Network 💎",
    "🍺 Löwenbräu WiFi 🍺",
    "⚙️ Maschinenbau Net ⚙️",
    "🏰 Bayern München WiFi 🏰",
    "🥨 Weißwurst Network 🥨",
    "🌲 Black Forest WiFi 🌲",
    "⚡ Mercedes Network ⚡",
    "🍻 Hofbräuhaus WiFi 🍻",
    "🎵 Wagner Network 🎵"
};

// PHASE 5 - Adding 5 more categories (25-29) - GLOBAL DOMINATION!

const char* russianSSIDs[] = {
    "🇷🇺 Russian WiFi 🇷🇺",
    "❄️ Siberian Network ❄️",
    "🏰 Red Square WiFi 🏰", 
    "🍶 Vodka Connection 🍶",
    "⚡ Soviet Network ⚡",
    "🐻 Bear Country WiFi 🐻",
    "🎭 Bolshoi Network 🎭",
    "🚀 Sputnik WiFi 🚀",
    "❄️ Moscow Winter Net ❄️",
    "⚔️ Kremlin Network ⚔️",
    "🎼 Tchaikovsky WiFi 🎼",
    "🏔️ Ural Mountains Net 🏔️",
    "⚡ Stalin Network ⚡",
    "🍖 Borscht WiFi 🍖",
    "❄️ Frozen Tundra Net ❄️",
    "🚂 Trans-Siberian WiFi 🚂",
    "⭐ Communist Star Net ⭐",
    "🎪 Russian Circus WiFi 🎪",
    "💎 Diamond Mine Network 💎",
    "⚡ KGB Surveillance ⚡",
    "🏰 St Petersburg WiFi 🏰",
    "❄️ Ice Palace Network ❄️"
};

const char* pureSymbolSSIDs[] = {
    "★☆✦✧✨✩✪✫✬✭✮✯",
    "♠♣♥♦♤♧♡♢",
    "▲▼◀▶◄►▲▼",
    "●○◐◑◒◓◔◕◖◗",
    "♪♫♬♩♭♮♯𝄞",
    "✓✗✘✚✙✛✜✝✞✟",
    "←↑→↓↔↕↖↗↘↙",
    "◊◇◈◉◎●○◐◑◒",
    "※※※※※※※※",
    "☼☽☾☀☁☂☃☄",
    "▓▒░░▒▓█▉▊▋▌▍▎▏",
    "◄◄◄◄►►►►",
    "♀♂⚢⚣⚤⚥⚦⚧⚨⚩",
    "∞∝∴∵∶∷∸∹∺∻",
    "▲△▼▽◀◁▶▷",
    "◊♦◇♢◈◉◎●○",
    "⚡⚡⚡⚡⚡⚡⚡⚡",
    "✈✉✊✋✌✍✎✏✐✑",
    "⚠⚡⚢⚣⚤⚥⚦⚧⚨⚩",
    "♨♩♪♫♬♭♮♯"
};

const char* internationalSSIDs[] = {
    "Café WiFi Naïve Résumé",
    "Björk Mötley Crüe Ñoño",
    "Rößler München Zürich",
    "Åse Øystein Æther",
    "François Château Médoc",
    "José María Peña Señor",
    "Škoda Český Dřevo",
    "Włochy Łódź Gdańsk",
    "Москва Санкт-Петербург",
    "Ελληνικά Αθήνα Θεσσαλονίκη",
    "العربية الرياض جدة",
    "中文 北京 上海 广州",
    "日本語 東京 大阪 京都",
    "한국어 서울 부산 대구",
    "ไทย กรุงเทพฯ เชียงใหม่",
    "Tiếng Việt Hà Nội Sài Gòn",
    "हिंदी दिल्ली मुंबई",
    "Türkçe İstanbul Ankara",
    "پارسی تهران اصفهان",
    "עברית תל אביב ירושלים",
    "Português São Paulo Rio",
    "Italiano Roma Milano"
};

const char* emojiOnlySSIDs[] = {
    "🎉🎊🎈🎁🎂🍰🧁",
    "🚀🛸🌟⭐✨💫🌙",
    "🦄🌈🦋🌸🌺🌻🌷",
    "🔥💥⚡🌟✨💫⭐",
    "🎮🎲🃏🎯🎪🎭🎨",
    "🍕🍔🍟🌭🥨🥯🍿",
    "🐶🐱🐭🐹🐰🦊🐻",
    "🌊🏖️🏄‍♂️🐚🐠🦈🐙",
    "❤️💛💚💙💜🖤🤍",
    "👑💎💍👸🤴👰🤵",
    "🌍🌎🌏🌐🗺️📍📌",
    "⚽🏀🏈⚾🎾🏐🏓",
    "🎵🎶🎼🎤🎧🎷🎸",
    "📱💻⌨️🖥️📺📷📹",
    "🚗🚕🚙🚌🚎🏎️🚓",
    "✈️🚁🚀🛸🚂🚇🚝",
    "🏠🏡🏢🏣🏤🏥🏦",
    "🌮🌯🥙🥗🍜🍝🍛",
    "⛰️🏔️🗻🌋🏕️⛺🏞️",
    "🎯🎪🎨🖼️🎭🎪🎢",
    "🔮🪄✨💫🌟⭐🌙",
    "🦸‍♂️🦸‍♀️🦹‍♂️🦹‍♀️🧙‍♂️🧙‍♀️🧚‍♂️"
};

const char* mixedEverythingSSIDs[] = {
    "★Café★ 🌟Naïve🌟 ◊WiFi◊",
    "🚀München♦Zürich⚡",
    "♪François🎵Château♪",
    "▲José▲ 🇪🇸María🇪🇸 ▼Peña▼",
    "◈Москва◈ 💫Wifi💫 ●Net●",
    "🦄Škoda🦄 ♠Český♠ 🌈WiFi🌈",
    "⚡中文⚡ 🐉WiFi🐉 ◊网络◊",
    "♦日本語♦ 🗾Tokyo🗾 ★Net★",
    "🎌한국어🎌 ◄Seoul► 💎WiFi💎",
    "♨ไทย♨ 🇹🇭Bangkok🇹🇭 ▲Net▲",
    "🌸Việt🌸 ◉Hà Nội◉ ★WiFi★",
    "♠हिंदी♠ 🇮🇳Delhi🇮🇳 ◆Net◆",
    "🌙Türkçe🌙 ◇Istanbul◇ ▼WiFi▼",
    "♪پارسی♪ 🇮🇷Tehran🇮🇷 ●Net●",
    "✡עברית✡ 🇮🇱Tel Aviv🇮🇱 ◊WiFi◊",
    "🌊Português🌊 ◈São Paulo◈",
    "🍝Italiano🍝 ♦Roma♦ 🎭Milano🎭",
    "⚔️Русский⚔️ 🐻Moscow🐻 ❄️WiFi❄️",
    "🏰Deutsch🏰 ◉Berlin◉ 🍺WiFi🍺",
    "🥖Français🥖 ♠Paris♠ 🗼WiFi🗼",
    "💃Español💃 ◇Madrid◇ 🌞WiFi🌞",
    "🎪العربية🎪 ♦Riyadh♦ 🕌WiFi🕌"
};

// PHASE 6 - Adding 5 more categories (30-34) - CYBERPUNK & HORROR!

const char* cyberpunkSSIDs[] = {
    "◢█◣ CYBER_NEXUS ◢█◣",
    "▓▒░ MATRIX_NODE ░▒▓",
    "║▌│█║▌│█║▌│█",
    "◤◢◣◥ NEO_NET ◤◢◣◥",
    "▀▄▀▄ GHOST_SHELL ▀▄▀▄",
    "●◐○ QUANTUM_LINK ○◐●",
    "▲▼▲ NEURAL_NET ▲▼▲",
    "░▒▓ BLADE_RUNNER ▓▒░",
    "◄►◄ AKIRA_GRID ►◄►",
    "██▓ CYBER_PUNK ▓██",
    "▬▬ι═══════ﺤ",
    "┌─┐┌─┐┌─┐ HACKER ┌─┐┌─┐┌─┐",
    "░░░▒▒▒▓▓▓███",
    "◥◤◢◣ TRON_NET ◢◣◥◤",
    "├──┤ DATA_STREAM ├──┤",
    "▓█▇▆▅▄▃▂▁",
    "┠─┨ CYBER_SPACE ┠─┨",
    "♦♢◇◆ NET_RUNNER ◆◇♢♦",
    "▶◀▼▲ DIGITAL_RAIN ▲▼◀▶",
    "⚡⚡⚡ NEON_GRID ⚡⚡⚡",
    "●○◐◑ CYBER_TOKYO ◑◐○●",
    "▬▬▬► GHOST_NET ◄▬▬▬"
};

const char* hellraiserSSIDs[] = {
    "⛓️ Cenobites WiFi Network ⛓️",
    "📦 Lament Configuration 📦",
    "🔧 Pinhead's Puzzle Box 🔧",
    "⛓️ Chains Of Hell Network ⛓️",
    "💀 We Have Such Sights 💀",
    "🎭 Pain And Pleasure WiFi 🎭",
    "⚫ Leviathan Network ⚫",
    "🔥 Labyrinth Of Suffering 🔥",
    "📦 Hellbound Heart WiFi 📦",
    "⛓️ Chatterer's Network ⛓️",
    "💉 Tears Are Gifts WiFi 💉",
    "🎪 Circus Of Damnation 🎪",
    "⚫ Engineer's Design ⚫",
    "🔧 Puzzle Box Portal 🔧",
    "💀 Butterball Network 💀",
    "⛓️ Female Cenobite WiFi ⛓️",
    "🔥 Hell's Geometry Network 🔥",
    "📦 Configuration Portal 📦",
    "💉 Angelique's Network 💉",
    "⚫ Channard's Hospital ⚫",
    "🎭 Doctor Hell WiFi 🎭",
    "⛓️ Torment Dimension ⛓️"
};

const char* batmanSSIDs[] = {
    "🦇 Wayne Manor WiFi 🦇",
    "🏢 Gotham City Network 🏢",
    "🚗 Batmobile Connection 🚗",
    "🦇 Dark Knight Network 🦇",
    "🃏 Joker's Wild Card WiFi 🃏",
    "❄️ Mr. Freeze Network ❄️",
    "🌿 Poison Ivy's Garden 🌿",
    "🐧 Penguin's Iceberg WiFi 🐧",
    "💀 Two-Face Coin Flip 💀",
    "🦇 Batcave Command Center 🦇",
    "🌃 Commissioner Gordon 🌃",
    "🎪 Arkham Asylum WiFi 🎪",
    "⚡ Robin Network ⚡",
    "🖤 Catwoman's Lair 🖤",
    "🏢 LexCorp Tower WiFi 🏢",
    "💎 Batman Beyond Net 💎",
    "🦅 Nightwing Network 🦅",
    "⚡ Oracle Database WiFi ⚡",
    "🌙 Batgirl Network 🌙",
    "💀 Red Hood WiFi 💀",
    "⚫ Justice League Net ⚫",
    "🦇 Gotham Knights WiFi 🦇"
};

const char* zombieSSIDs[] = {
    "🧟‍♂️ Zombie Outbreak WiFi 🧟‍♂️",
    "💀 Walking Dead Network 💀",
    "🧟‍♀️ Undead Connection 🧟‍♀️",
    "🏥 CDC Quarantine Zone 🏥",
    "⚠️ ZOMBIE ALERT WiFi ⚠️",
    "🧟‍♂️ Brain Eaters Network 🧟‍♂️",
    "💉 Infection Control WiFi 💉",
    "🏚️ Safe House Network 🏚️",
    "🔫 Zombie Hunters WiFi 🔫",
    "💀 Resident Evil Net 💀",
    "🧟‍♀️ Shambling Horde WiFi 🧟‍♀️",
    "⚠️ Biohazard Network ⚠️",
    "🏥 T-Virus Outbreak 🏥",
    "💀 Left 4 Dead WiFi 💀",
    "🧟‍♂️ Dead Rising Network 🧟‍♂️",
    "⚠️ Zombie Survival WiFi ⚠️",
    "💉 Patient Zero Network 💉",
    "🔥 Burn The Infected 🔥",
    "🏚️ Barricade Network 🏚️",
    "💀 Day Of The Dead WiFi 💀",
    "🧟‍♀️ World War Z Network 🧟‍♀️",
    "⚠️ Last Stand WiFi ⚠️"
};

const char* nuclearSSIDs[] = {
    "☢️ NUCLEAR WARNING ☢️",
    "⚠️ RADIATION HAZARD ⚠️",
    "☢️ Chernobyl Network ☢️",
    "⚠️ ATOMIC ENERGY WiFi ⚠️",
    "☢️ Fallout Shelter Net ☢️",
    "⚠️ MELTDOWN IMMINENT ⚠️",
    "☢️ Reactor Core WiFi ☢️",
    "⚠️ GEIGER COUNTER HIGH ⚠️",
    "☢️ Nuclear Waste Site ☢️",
    "⚠️ URANIUM ENRICHMENT ⚠️",
    "☢️ Manhattan Project ☢️",
    "⚠️ ATOMIC BOMB WiFi ⚠️",
    "☢️ Nuclear Winter Net ☢️",
    "⚠️ PLUTONIUM STORAGE ⚠️",
    "☢️ Three Mile Island ☢️",
    "⚠️ FUKUSHIMA ALERT ⚠️",
    "☢️ Nuclear Submarine ☢️",
    "⚠️ CONTAMINATION ZONE ⚠️",
    "☢️ Atomic Testing WiFi ☢️",
    "⚠️ NUCLEAR SILO NET ⚠️",
    "☢️ Radioactive Decay ☢️",
    "⚠️ CRITICAL MASS WiFi ⚠️"
};

// PHASE 7 - DIVINE & DEMONIC WARFARE! (Categories 35-39)

const char* divineSSIDs[] = {
    "✝️ GOD'S WIFI NETWORK ✝️",
    "🙏 DIVINE CONNECTION 🙏",
    "✨ HEAVENLY INTERNET ✨",
    "👼 ANGEL WIFI ZONE 👼",
    "✝️ JESUS SAVES WIFI ✝️",
    "🕊️ HOLY SPIRIT NETWORK 🕊️",
    "⛪ CHURCH WIFI ⛪",
    "🙏 PRAYER REQUEST WIFI 🙏",
    "✨ MIRACLE NETWORK ✨",
    "👼 ARCHANGEL MICHAEL 👼",
    "✝️ CROSS OF CHRIST ✝️",
    "🕊️ PEACEFUL DOVE 🕊️",
    "⛪ CATHEDRAL WIFI ⛪",
    "🙏 BLESSED NETWORK 🙏",
    "✨ DIVINE LIGHT ✨",
    "👼 GUARDIAN ANGEL 👼",
    "✝️ FAITH HOPE LOVE ✝️",
    "🕊️ GRACE AND MERCY 🕊️",
    "⛪ SANCTUARY WIFI ⛪",
    "🙏 GOD'S LOVE NETWORK 🙏",
    "✨ ETERNAL BLESSING ✨",
    "👼 HEAVENLY HOST 👼"
};

const char* satanSSIDs[] = {
    "👹 SATAN'S WIFI 666 👹",
    "🔥 HELL'S NETWORK 🔥",
    "😈 DEMON WIFI ZONE 😈",
    "🖤 DARK LORD'S NET 🖤",
    "👹 LUCIFER'S INTERNET 👹",
    "🔥 INFERNAL NETWORK 🔥",
    "😈 EVIL SPIRIT WIFI 😈",
    "🖤 DARKNESS FALLS 🖤",
    "👹 BEELZEBUB'S WIFI 👹",
    "🔥 GATES OF HELL 🔥",
    "😈 DEMON POSSESSION 😈",
    "🖤 SHADOW REALM 🖤",
    "👹 DEVIL'S ADVOCATE 👹",
    "🔥 HELLFIRE NETWORK 🔥",
    "😈 FALLEN ANGEL WIFI 😈",
    "🖤 ABYSS NETWORK 🖤",
    "👹 PRINCE OF DARKNESS 👹",
    "🔥 ETERNAL DAMNATION 🔥",
    "😈 SINISTER WIFI 😈",
    "🖤 VOID OF DESPAIR 🖤",
    "👹 ANTICHRIST NETWORK 👹",
    "🔥 LAKE OF FIRE 🔥"
};

const char* asylumSSIDs[] = {
    "🏥 ARKHAM ASYLUM WIFI 🏥",
    "🧠 INSANITY NETWORK 🧠",
    "💊 PSYCHIATRIC WARD 💊",
    "🏥 MENTAL HOSPITAL 🏥",
    "🧠 LOBOTOMY WIFI 🧠",
    "💊 STRAIGHTJACKET NET 💊",
    "🏥 BEDLAM INSTITUTION 🏥",
    "🧠 MADHOUSE WIFI 🧠",
    "💊 ELECTROSHOCK THERAPY 💊",
    "🏥 ASYLUM FOR INSANE 🏥",
    "🧠 PSYCHOTIC BREAK 🧠",
    "💊 MEDICATION TIME 💊",
    "🏥 SANITARIUM WIFI 🏥",
    "🧠 SPLIT PERSONALITY 🧠",
    "💊 THERAPY SESSION 💊",
    "🏥 NERVOUS BREAKDOWN 🏥",
    "🧠 MENTAL DISORDER 🧠",
    "💊 ANTIPSYCHOTIC NET 💊",
    "🏥 ISOLATION WARD 🏥",
    "🧠 HEARING VOICES 🧠",
    "💊 PADDED CELL WIFI 💊",
    "🏥 MAXIMUM SECURITY 🏥"
};

const char* christmasSSIDs[] = {
    "🎄 SANTA'S WIFI WORKSHOP 🎄",
    "🎅 NORTH POLE NETWORK 🎅",
    "🎁 CHRISTMAS MIRACLE 🎁",
    "⭐ STAR OF BETHLEHEM ⭐",
    "🎄 JINGLE BELLS WIFI 🎄",
    "🎅 HO HO HO NETWORK 🎅",
    "🎁 GIFT EXCHANGE WIFI 🎁",
    "⭐ CHRISTMAS SPIRIT ⭐",
    "🎄 DECK THE HALLS 🎄",
    "🎅 REINDEER WIFI ZONE 🎅",
    "🎁 UNDER THE TREE 🎁",
    "⭐ SILENT NIGHT NET ⭐",
    "🎄 MISTLETOE NETWORK 🎄",
    "🎅 CANDY CANE WIFI 🎅",
    "🎁 CHRISTMAS MORNING 🎁",
    "⭐ WISE MEN NETWORK ⭐",
    "🎄 HOLLY JOLLY WIFI 🎄",
    "🎅 SLEIGH RIDE NET 🎅",
    "🎁 WRAPPED WITH LOVE 🎁",
    "⭐ CHRISTMAS BLESSING ⭐",
    "🎄 WINTER WONDERLAND 🎄",
    "🎅 MERRY CHRISTMAS 🎅"
};

const char* halloweenSSIDs[] = {
    "🎃 PUMPKIN PATCH WIFI 🎃",
    "👻 BOO! GHOST NETWORK 👻",
    "🦇 BATCAVE INTERNET 🦇",
    "🕷️ SPIDER WEB WIFI 🕷️",
    "🎃 JACK-O-LANTERN NET 🎃",
    "👻 HAUNTED HOUSE WIFI 👻",
    "🦇 VAMPIRE'S LAIR 🦇",
    "🕷️ CREEPY CRAWLERS 🕷️",
    "🎃 TRICK OR TREAT 🎃",
    "👻 POLTERGEIST NETWORK 👻",
    "🦇 MIDNIGHT FLIGHT 🦇",
    "🕷️ BLACK WIDOW WIFI 🕷️",
    "🎃 HALLOWEEN NIGHT 🎃",
    "👻 GHOSTLY APPARITION 👻",
    "🦇 DRACULA'S CASTLE 🦇",
    "🕷️ TANGLED WEB 🕷️",
    "🎃 AUTUMN HARVEST 🎃",
    "👻 SPIRIT WORLD 👻",
    "🦇 NIGHT CREATURES 🦇",
    "🕷️ EIGHT LEGS WIFI 🕷️",
    "🎃 ORANGE AND BLACK 🎃",
    "👻 SCARY STORIES 👻"
};

// PHASE 8 - GAMING & GEEK CULTURE SSIDS
const char* gamingNetworkSSIDs[] = {
    "🎮 GAME OVER MAN 🎮",
    "🕹️ RESPAWN POINT 🕹️",
    "⚡ PWNED NETWORK ⚡",
    "🎯 HEADSHOT WIFI 🎯",
    "🚀 ROCKET JUMP 🚀",
    "🔫 FRAG ZONE 🔫",
    "💥 DOUBLE KILL 💥",
    "🏆 VICTORY ROYALE 🏆",
    "⚔️ BOSS FIGHT ⚔️",
    "🎲 CRITICAL HIT 🎲",
    "🛡️ DEFENSE MODE 🛡️",
    "💎 LEGENDARY LOOT 💎",
    "🔥 FIRE RATE MAX 🔥",
    "⭐ ACHIEVEMENT GET ⭐",
    "🎪 GAME CENTER 🎪"
};

const char* retrogamingSSIDs[] = {
    "👾 8-BIT PARADISE 👾",
    "🕹️ ARCADE CABINET 🕹️",
    "📺 CRT MONITOR 📺",
    "🎮 NINTENDO POWER 🎮",
    "🔸 PIXEL PERFECT 🔸",
    "⚡ CHEAT CODE ON ⚡",
    "🎯 HIGH SCORE 🎯",
    "💿 CARTRIDGE BLOW 💿",
    "🔊 BEEP BOOP WIFI 🔊",
    "⭐ STAR POWER ⭐",
    "🍄 EXTRA LIFE 🍄",
    "🏁 FINAL LEVEL 🏁",
    "🎵 8-BIT BEATS 🎵",
    "💾 SAVE STATE 💾",
    "🎪 RETRO GAMING 🎪"
};

const char* boardgamesSSIDs[] = {
    "🎲 ROLL FOR WIFI 🎲",
    "♟️ CHESS MASTER ♟️",
    "🃏 WILD CARD NET 🃏",
    "🎯 BULLSEYE WIFI 🎯",
    "🏰 CASTLE NETWORK 🏰",
    "⚔️ BOARD WARFARE ⚔️",
    "🎮 GAME NIGHT 🎮",
    "🔥 CRITICAL ROLL 🔥",
    "💎 RARE CARD 💎",
    "🎪 TABLETOP WIFI 🎪",
    "🎭 ROLE PLAYING 🎭",
    "🗡️ SWORD & SORCERY 🗡️",
    "🏆 CHAMPION NET 🏆",
    "⚡ POWER PLAY ⚡",
    "🎨 STRATEGY WIFI 🎨"
};

const char* geekCultureSSIDs[] = {
    "🤓 NERD HERD WIFI 🤓",
    "⚡ GEEK POWER ⚡",
    "🔬 SCIENCE RULES 🔬",
    "🤖 ROBOT OVERLORDS 🤖",
    "💻 CODE WARRIOR 💻",
    "📚 BOOK WORM NET 📚",
    "🎭 COSPLAY WIFI 🎭",
    "🎪 COMIC CON NET 🎪",
    "🔥 FANBOY ZONE 🔥",
    "⭐ GEEK CULTURE ⭐",
    "🎯 NERD PARADISE 🎯",
    "🚀 TECH HEAVEN 🚀",
    "💎 RARE COLLECTIBLE 💎",
    "🏆 GEEK PRIDE 🏆",
    "🎮 NERD CAVE 🎮"
};

const char* scifiSSIDs[] = {
    "🚀 STARSHIP WIFI 🚀",
    "👽 ALIEN CONTACT 👽",
    "🌌 GALAXY NET 🌌",
    "⚡ WARP SPEED ⚡",
    "🤖 ANDROID DREAMS 🤖",
    "🔬 LABORATORY 42 🔬",
    "🌟 STAR TREK NET 🌟",
    "💫 TIME MACHINE 💫",
    "🛸 UFO HOTSPOT 🛸",
    "⭐ SPACE STATION ⭐",
    "🔥 LASER CANNON 🔥",
    "💎 CRYSTAL POWER 💎",
    "🏆 FUTURE TECH 🏆",
    "🎯 COSMIC WIFI 🎯",
    "🌊 QUANTUM NET 🌊"
};

// Category structure
struct BeaconCategory {
    const char* name;
    const char** ssids;
    int count;
};

BeaconCategory categories[] = {
    {"Government/LEO", governmentSSIDs, sizeof(governmentSSIDs)/sizeof(governmentSSIDs[0])},
    {"Funny Names", funnySSIDs, sizeof(funnySSIDs)/sizeof(funnySSIDs[0])},
    {"Suspicious", suspiciousSSIDs, sizeof(suspiciousSSIDs)/sizeof(suspiciousSSIDs[0])},
    {"Tech/Error", techSSIDs, sizeof(techSSIDs)/sizeof(techSSIDs[0])},
    {"Entertainment", entertainmentSSIDs, sizeof(entertainmentSSIDs)/sizeof(entertainmentSSIDs[0])},
    {"Offensive", offensiveSSIDs, sizeof(offensiveSSIDs)/sizeof(offensiveSSIDs[0])},
    {"Gaming", gamerSSIDs, sizeof(gamerSSIDs)/sizeof(gamerSSIDs[0])},
    {"Food/Restaurants", foodSSIDs, sizeof(foodSSIDs)/sizeof(foodSSIDs[0])},
    {"Hacking/Security", hackingSSIDs, sizeof(hackingSSIDs)/sizeof(hackingSSIDs[0])},
    // PHASE 2 - Categories 10-14
    {"Corporate", corporateSSIDs, sizeof(corporateSSIDs)/sizeof(corporateSSIDs[0])},
    {"Adult Content", adultSSIDs, sizeof(adultSSIDs)/sizeof(adultSSIDs[0])},
    {"Aliens & UFOs", alienSSIDs, sizeof(alienSSIDs)/sizeof(alienSSIDs[0])},
    {"Dogs & Puppies", dogSSIDs, sizeof(dogSSIDs)/sizeof(dogSSIDs[0])},
    {"Cats & Kittens", catSSIDs, sizeof(catSSIDs)/sizeof(catSSIDs[0])},
    // PHASE 3 - Categories 15-19
    {"Symbols & Icons", symbolSSIDs, sizeof(symbolSSIDs)/sizeof(symbolSSIDs[0])},
    {"Astrology", astrologySSIDs, sizeof(astrologySSIDs)/sizeof(astrologySSIDs[0])},
    {"Astronomy", astronomySSIDs, sizeof(astronomySSIDs)/sizeof(astronomySSIDs[0])},
    {"Sports", sportsSSIDs, sizeof(sportsSSIDs)/sizeof(sportsSSIDs[0])},
    {"Variety Mix", varietySSIDs, sizeof(varietySSIDs)/sizeof(varietySSIDs[0])},
    // PHASE 4 - Categories 20-24 - THE LEGENDS!
    {"Hunter S. Thompson", hunterThompsonSSIDs, sizeof(hunterThompsonSSIDs)/sizeof(hunterThompsonSSIDs[0])},
    {"Dead Kennedys", deadKennedysSSIDs, sizeof(deadKennedysSSIDs)/sizeof(deadKennedysSSIDs[0])},
    {"Crass Punk", crassSSIDs, sizeof(crassSSIDs)/sizeof(crassSSIDs[0])},
    {"Insane & Crazy", insaneSSIDs, sizeof(insaneSSIDs)/sizeof(insaneSSIDs[0])},
    {"German Language", germanSSIDs, sizeof(germanSSIDs)/sizeof(germanSSIDs[0])},
    // PHASE 5 - Categories 25-29 - GLOBAL DOMINATION!
    {"Russian Language", russianSSIDs, sizeof(russianSSIDs)/sizeof(russianSSIDs[0])},
    {"Pure Symbols", pureSymbolSSIDs, sizeof(pureSymbolSSIDs)/sizeof(pureSymbolSSIDs[0])},
    {"International", internationalSSIDs, sizeof(internationalSSIDs)/sizeof(internationalSSIDs[0])},
    {"Emoji Only", emojiOnlySSIDs, sizeof(emojiOnlySSIDs)/sizeof(emojiOnlySSIDs[0])},
    {"Mixed Everything", mixedEverythingSSIDs, sizeof(mixedEverythingSSIDs)/sizeof(mixedEverythingSSIDs[0])},
    // PHASE 6 - Categories 30-34 - CYBERPUNK & HORROR!
    {"Cyberpunk Tech", cyberpunkSSIDs, sizeof(cyberpunkSSIDs)/sizeof(cyberpunkSSIDs[0])},
    {"Hellraiser Horror", hellraiserSSIDs, sizeof(hellraiserSSIDs)/sizeof(hellraiserSSIDs[0])},
    {"Batman Universe", batmanSSIDs, sizeof(batmanSSIDs)/sizeof(batmanSSIDs[0])},
    {"Zombie Apocalypse", zombieSSIDs, sizeof(zombieSSIDs)/sizeof(zombieSSIDs[0])},
    {"Nuclear Warning", nuclearSSIDs, sizeof(nuclearSSIDs)/sizeof(nuclearSSIDs[0])},
    // PHASE 7 - DIVINE & DEMONIC WARFARE! Categories 35-39
    {"God & Divine", divineSSIDs, sizeof(divineSSIDs)/sizeof(divineSSIDs[0])},
    {"Satan & Dark", satanSSIDs, sizeof(satanSSIDs)/sizeof(satanSSIDs[0])},
    {"Mental Asylum", asylumSSIDs, sizeof(asylumSSIDs)/sizeof(asylumSSIDs[0])},
    {"Christmas", christmasSSIDs, sizeof(christmasSSIDs)/sizeof(christmasSSIDs[0])},
    {"Halloween", halloweenSSIDs, sizeof(halloweenSSIDs)/sizeof(halloweenSSIDs[0])},
    // PHASE 8 - GAMING & GEEK CULTURE! Categories 40-44
    {"Gaming Networks", gamingNetworkSSIDs, sizeof(gamingNetworkSSIDs)/sizeof(gamingNetworkSSIDs[0])},
    {"Retro Gaming", retrogamingSSIDs, sizeof(retrogamingSSIDs)/sizeof(retrogamingSSIDs[0])},
    {"Board Games", boardgamesSSIDs, sizeof(boardgamesSSIDs)/sizeof(boardgamesSSIDs[0])},
    {"Geek Culture", geekCultureSSIDs, sizeof(geekCultureSSIDs)/sizeof(geekCultureSSIDs[0])},
    {"Science Fiction", scifiSSIDs, sizeof(scifiSSIDs)/sizeof(scifiSSIDs[0])}
};

int totalCategories = sizeof(categories) / sizeof(categories[0]);

// State management
enum BeaconState {
    STATE_MENU,
    STATE_SPAMMING
};

BeaconState currentState = STATE_MENU;
int selectedCategory = 0;
bool spamming = false;
unsigned long lastSpam = 0;
unsigned long beaconCount = 0;
int currentSSIDIndex = 0;
BeaconCategory* activeCategory = nullptr;

// Button state management  
bool leftButtonPressed = false;
bool rightButtonPressed = false;
unsigned long buttonPressTime = 0;

// Button handling functions (adapted from 341 Effects)
bool leftButtonPress() {
    static bool lastState = false;
    bool currentState = (digitalRead(PIN_BTN_L) == LOW);
    
    if (currentState && !lastState) {
        lastState = currentState;
        return true;
    }
    lastState = currentState;
    return false;
}

bool rightButtonPress() {
    static bool lastState = false;
    bool currentState = (digitalRead(PIN_BTN_R) == LOW);
    
    if (currentState && !lastState) {
        lastState = currentState;
        return true;
    }
    lastState = currentState;
    return false;
}

// SIMPLIFIED - now only used for single beacon testing if needed
void sendBeacon(const char* ssid) {
    uint8_t beaconPacket[BEACON_PKT_LEN];
    uint8_t macAddr[6];
    
    // Generate random MAC address (Bruce's method)
    generateRandomWiFiMac(macAddr);
    
    // Prepare beacon packet using Bruce's working template
    prepareBeaconPacket(beaconPacket, macAddr, ssid, strlen(ssid), wifi_channel, true);
    
    // CRITICAL: Use WIFI_IF_STA and Bruce's exact timing
    for (int k = 0; k < 2; k++) {
        esp_wifi_80211_tx(WIFI_IF_STA, beaconPacket, BEACON_PKT_LEN, 0);
        vTaskDelay(1 / portTICK_PERIOD_MS);
    }
}

// Display functions adapted for circular screen
void drawCenterText(const char* text, int y, uint16_t color, int textSize = 2) {
    tft.setTextColor(color, TFT_BLACK);
    tft.setTextSize(textSize);
    
    int textWidth = strlen(text) * 6 * textSize; // Approximate width
    int x = (128 - textWidth) / 2;
    if (x < 0) x = 0;
    
    tft.setCursor(x, y);
    tft.print(text);
}

void drawScrollingText(const char* text, int y, uint16_t color) {
    static int scrollPos = 128;
    static unsigned long lastScroll = 0;
    
    if (millis() - lastScroll > 50) {
        tft.setTextColor(color, TFT_BLACK);
        tft.setTextSize(1);
        
        // Clear the line
        tft.fillRect(0, y, 128, 8, TFT_BLACK);
        
        // Draw scrolling text
        tft.setCursor(scrollPos, y);
        tft.print(text);
        
        scrollPos -= 2;
        if (scrollPos < -strlen(text) * 6) {
            scrollPos = 128;
        }
        
        lastScroll = millis();
    }
}

void showCategoryMenu() {
    tft.fillScreen(TFT_BLACK);
    
    // Title
    drawCenterText("T-QT BEACON", 10, TFT_CYAN, 2);
    
    // Instructions
    drawCenterText("L: Navigate", 30, TFT_WHITE, 1);
    drawCenterText("R: Start Spam", 45, TFT_WHITE, 1);
    
    // Current category (highlighted)
    String categoryText = "Category: " + String(selectedCategory + 1) + "/" + String(totalCategories);
    drawCenterText(categoryText.c_str(), 65, TFT_YELLOW, 1);
    
    // Category name
    drawCenterText(categories[selectedCategory].name, 80, TFT_GREEN, 2);
    
    // Sample SSID count
    String countText = String(categories[selectedCategory].count) + " SSIDs";
    drawCenterText(countText.c_str(), 105, TFT_MAGENTA, 1);
}

void showSpammingStatus() {
    static unsigned long lastUpdate = 0;
    
    // Limit display updates to reduce performance impact
    if (millis() - lastUpdate < 200) return;
    lastUpdate = millis();
    
    tft.fillScreen(TFT_BLACK);
    
    // Title
    drawCenterText("SPAMMING ACTIVE", 10, TFT_RED, 1);
    
    // Category being spammed
    drawCenterText(activeCategory->name, 25, TFT_CYAN, 1);
    
    // Beacon count
    String countText = "Beacons: " + String(beaconCount);
    drawCenterText(countText.c_str(), 45, TFT_GREEN, 1);
    
    // Channel info
    String channelText = "CH: " + String(channels[currentChannel]);
    drawCenterText(channelText.c_str(), 60, TFT_YELLOW, 1);
    
    // Current SSID (static instead of scrolling for performance)
    if (activeCategory && currentSSIDIndex < activeCategory->count) {
        String ssid = String(activeCategory->ssids[currentSSIDIndex]);
        if (ssid.length() > 20) ssid = ssid.substring(0, 20) + "...";
        drawCenterText(ssid.c_str(), 80, TFT_WHITE, 1);
    }
    
    // Stop instruction
    drawCenterText("L: Stop Spam", 100, TFT_MAGENTA, 1);
    
    // Performance indicator
    String perfText = "Rate: " + String(1000/(millis()-lastUpdate)) + "/s";
    drawCenterText(perfText.c_str(), 115, TFT_ORANGE, 1);
}

// BRUCE'S RAPID SPAM APPROACH - SEND ALL BEACONS IN CATEGORY QUICKLY
void spamAllBeaconsInCategory() {
    if (!activeCategory || !spamming) return;
    
    // Bruce's method: cycle through MULTIPLE SSIDs rapidly per loop iteration
    uint8_t beaconPacket[BEACON_PKT_LEN];
    uint8_t macAddr[6];
    
    // Send 5-10 different SSIDs per iteration (like Bruce's rapid spam)
    int ssidsToSend = min(5, activeCategory->count);
    
    for (int i = 0; i < ssidsToSend; i++) {
        const char* currentSSID = activeCategory->ssids[currentSSIDIndex];
        
        // Generate random MAC for this SSID
        generateRandomWiFiMac(macAddr);
        
        // Prepare beacon packet using Bruce's exact method
        prepareBeaconPacket(beaconPacket, macAddr, currentSSID, strlen(currentSSID), wifi_channel, true);
        
        // Send exactly 2 packets like Bruce (critical for consumer device visibility)
        for (int k = 0; k < 2; k++) {
            esp_wifi_80211_tx(WIFI_IF_STA, beaconPacket, BEACON_PKT_LEN, 0);
            vTaskDelay(1 / portTICK_PERIOD_MS);  // Bruce's exact timing between packets
        }
        
        // Move to next SSID
        currentSSIDIndex++;
        if (currentSSIDIndex >= activeCategory->count) {
            currentSSIDIndex = 0;
            
            // Bruce's approach: change channel only after cycling through ALL SSIDs
            nextChannel();  // Use Bruce's channel management
            break; // Exit after full cycle
        }
        
        // Small delay between different SSIDs in this burst
        vTaskDelay(2 / portTICK_PERIOD_MS);
    }
}

void handleMenuInput() {
    // Left button: Navigate through categories
    if (leftButtonPress()) {
        selectedCategory++;
        if (selectedCategory >= totalCategories) {
            selectedCategory = 0;
        }
        showCategoryMenu();
        Serial.printf("Selected category: %s\n", categories[selectedCategory].name);
    }
    
    // Right button: Start spamming selected category
    if (rightButtonPress()) {
        activeCategory = &categories[selectedCategory];
        currentSSIDIndex = 0;
        spamming = true;
        beaconCount = 0;
        currentState = STATE_SPAMMING;
        
        // Set random channel to avoid conflicts
        currentChannel = random(0, sizeof(channels)/sizeof(channels[0]));
        esp_wifi_set_channel(channels[currentChannel], WIFI_SECOND_CHAN_NONE);
        
        showSpammingStatus();
        Serial.printf("Started spamming category: %s\n", activeCategory->name);
    }
}

void handleSpammingInput() {
    // Left button: Stop spamming
    if (leftButtonPress()) {
        spamming = false;
        currentState = STATE_MENU;
        showCategoryMenu();
        Serial.printf("Stopped spamming. Total beacons sent: %lu\n", beaconCount);
    }
}

void setupBeacon() {
    Serial.println("Setting up T-QT Pro Beacon...");
    
    // Initialize TFT display (using proven T-QT Pro settings)
    tft.init();
    tft.setRotation(0);  // Portrait orientation
    tft.fillScreen(TFT_BLACK);
    
    // Initialize button pins
    pinMode(PIN_BTN_L, INPUT_PULLUP);
    pinMode(PIN_BTN_R, INPUT_PULLUP);
    
    // Initialize random seed for better MAC randomization
    randomSeed(analogRead(0) + millis());
    
    // BRUCE'S WORKING WIFI SETUP - APSTA mode is critical!
    Serial.println("Initializing WiFi in APSTA mode...");
    if (!WiFi.mode(WIFI_MODE_APSTA)) {
        Serial.println("Failed to set WiFi mode APSTA");
        return;
    }
    vTaskDelay(pdMS_TO_TICKS(100));

    // Bruce's AP setup - this is what makes it work!
    if (!WiFi.softAP("BruceAttack", "", 1, 1, 4, false)) {
        Serial.println("Failed starting AP Attacker");
        return;
    }
    vTaskDelay(pdMS_TO_TICKS(100));
    
    // Set initial channel
    nextChannel();
    
    // Show initial menu (no auto-start to fix brucewifi issue)
    showCategoryMenu();
    
    Serial.println("T-QT Pro Beacon setup complete!");
    Serial.printf("Available categories: %d\n", totalCategories);
    Serial.println("Press RIGHT button to start spamming selected category");
    for (int i = 0; i < totalCategories; i++) {
        Serial.printf("  %d. %s (%d SSIDs)\n", i+1, categories[i].name, categories[i].count);
    }
}

void loopBeacon() {
    switch (currentState) {
        case STATE_MENU:
            handleMenuInput();
            break;
            
        case STATE_SPAMMING:
            handleSpammingInput();
            
            // Bruce's approach: spam ALL SSIDs rapidly, not one at a time
            if (spamming && millis() - lastSpam > 10) { // Fast spam like Bruce
                spamAllBeaconsInCategory();
                lastSpam = millis();
                beaconCount++;
                
                // Update display less frequently to avoid slowdown
                if (beaconCount % 50 == 0) { // Less frequent display updates
                    showSpammingStatus();
                }
            }
            break;
    }
}