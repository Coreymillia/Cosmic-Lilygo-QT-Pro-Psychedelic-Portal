/*
 * T-QT Pro WiFi Beacon Spammer
 * Port of M5StickC Plus2 "Spamtastic Beacon" to LilyGO T-QT Pro
 * 
 * Features:
 * - WiFi beacon spam with multiple categories
 * - Circular display optimized UI
 * - Button controls for navigation
 * - Real-time beacon status
 * 
 * Hardware: LilyGO T-QT Pro ESP32-S3
 * Display: 128x128 GC9A01 circular TFT
 * 
 * Based on working 341 Effects foundation
 */

#include <Arduino.h>
#include <WiFi.h>
#include "esp_wifi.h"
#include <TFT_eSPI.h>

// Forward declarations
void setupBeacon();
void loopBeacon();

void setup() {
    Serial.begin(115200);
    Serial.println("T-QT Pro Beacon Spammer Starting...");
    
    // Initialize beacon functionality (includes TFT setup)
    setupBeacon();
    
    Serial.println("T-QT Pro Beacon Ready!");
}

void loop() {
    // Handle beacon functionality only
    loopBeacon();
    
    delay(10);
}